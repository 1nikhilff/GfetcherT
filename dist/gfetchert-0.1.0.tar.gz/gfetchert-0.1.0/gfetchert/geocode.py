from geopy.geocoders import Nominatim

def get_coordinates(location: str):
    geolocator = Nominatim(user_agent="Gfetchert")
    loc = geolocator.geocode(location)
    if loc:
        return loc.latitude, loc.longitude, loc.address
    parts = location.split(',')
    while len(parts) > 1:
        parts.pop(0)
        broader = ','.join(parts)
        loc = geolocator.geocode(broader.strip())
        if loc:
            print(f"Using broader match: {loc.address}")
            return loc.latitude, loc.longitude, loc.address
    raise ValueError(f"Location not found: {location}. Try a nearby district or give lat/lon.")
