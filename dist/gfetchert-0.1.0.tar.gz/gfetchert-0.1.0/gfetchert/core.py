import os, requests, gzip, shutil
import pandas as pd, rasterio
from datetime import datetime, timedelta
from .geocode import get_coordinates

BASE_URL = ("https://data.chc.ucsb.edu/products/CHIRPS-2.0/"
            "global_daily/tifs/p05/{year}/chirps-v2.0.{year}.{month:02d}.{day:02d}.tif.gz")

def get_rainfall(*, lat: float | None=None, lon: float | None=None,
                 location: str | None=None, start: str, end: str,
                 download_dir: str="chirps_data") -> pd.DataFrame:
    if location and (lat is None or lon is None):
        lat, lon, resolved = get_coordinates(location)
        print(f"Resolved: {resolved} -> ({lat}, {lon})")
    elif lat is None or lon is None:
        raise ValueError("Provide either (lat, lon) or location.")

    os.makedirs(download_dir, exist_ok=True)
    start_dt = datetime.strptime(start, "%Y-%m-%d")
    end_dt   = datetime.strptime(end,   "%Y-%m-%d")

    rows = []
    d = start_dt
    while d <= end_dt:
        y, m, dd = d.year, d.month, d.day
        gz = f"chirps-v2.0.{y}.{m:02d}.{dd:02d}.tif.gz"
        gz_path = os.path.join(download_dir, gz)
        tif_path = gz_path[:-3]
        url = BASE_URL.format(year=y, month=m, day=dd)

        if not os.path.exists(tif_path):
            r = requests.get(url, timeout=60)
            if r.status_code != 200:
                rows.append({"date": d.strftime("%Y-%m-%d"), "rainfall_mm": None})
                d += timedelta(days=1); continue
            with open(gz_path, "wb") as f: f.write(r.content)
            try:
                with gzip.open(gz_path, "rb") as fin, open(tif_path, "wb") as fout:
                    shutil.copyfileobj(fin, fout)
            finally:
                if os.path.exists(gz_path): os.remove(gz_path)

        try:
            with rasterio.open(tif_path) as src:
                row, col = src.index(lon, lat)  # (lon, lat)
                band = src.read(1)
                if 0 <= row < band.shape[0] and 0 <= col < band.shape[1]:
                    val = band[row, col]
                    if val == src.nodata or val < 0 or val > 500:
                        rain = None
                    else:
                        rain = float(val)
                else:
                    rain = None
        except Exception:
            rain = None

        rows.append({"date": d.strftime("%Y-%m-%d"), "rainfall_mm": rain})
        d += timedelta(days=1)

    return pd.DataFrame(rows)
